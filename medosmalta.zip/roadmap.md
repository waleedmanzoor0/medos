# MedOS roadmap

- [x] Iteration 1: auth, database, dashboard, Study Hub, Task Manager, Smart Planner, sample data, export
- [x] Iteration 2: Revision Centre (flashcards with spaced repetition, quizzes, difficult topics list, exports and checks)
- [x] Iteration 3: Money Hub (income, expenses, budgets, savings goals in EUR, charts; signed-in CRUD verified)
- [x] Iteration 4: Progress Analytics (scheduled study time by module, quiz performance, planned-day consistency, weekly goals; verified with saved records)
- [ ] Later: AI flashcards, lecture summaries, oral exam practice (marked unverified)
